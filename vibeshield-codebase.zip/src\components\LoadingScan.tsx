import { useEffect, useState } from 'react';

const SCAN_STEPS = [
  "DECOMPILING AST & SCANNING CODEBASE AGAINST OWASP TOP 10 SECURITY SIGNATURES...",
  "AUDITING DEPENDENCIES FOR KNOWN CVE VULNERABILITIES...",
  "ANALYZING DYNAMIC SQL CONCATENATIONS & SQL INJECTION RISKS...",
  "CHECKING FOR HARDCODED API KEYS & EXPOSED SECRETS...",
  "EVALUATING SANITIZATION PROCEDURES & XSS THREAT VECTORS...",
  "COMPILING FINAL VIBESHIELD SECURITY AUDIT REPORT..."
];

export function LoadingScan() {
  const [progress, setProgress] = useState(15);
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    const progressTimer = setInterval(() => {
      setProgress((prev) => (prev >= 92 ? 92 : prev + Math.floor(Math.random() * 8) + 4));
    }, 200);

    const stepTimer = setInterval(() => {
      setStepIndex((prev) => (prev + 1) % SCAN_STEPS.length);
    }, 600);

    return () => {
      clearInterval(progressTimer);
      clearInterval(stepTimer);
    };
  }, []);

  return (
    <div className="w-full max-w-xl mx-auto p-8 sm:p-10 rounded-3xl bg-[#09090b] border-2 border-white/20 shadow-2xl space-y-6 text-center animate-fade-in relative overflow-hidden font-inter">
      {/* Background Ambient Orbs */}
      <div className="absolute -top-16 -left-16 w-48 h-48 bg-[#5E0ED7]/30 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-16 -right-16 w-48 h-48 bg-[#00F5FF]/20 rounded-full blur-3xl pointer-events-none" />

      {/* Cyber Spinning Radar Ring Icon */}
      <div className="relative w-20 h-20 sm:w-24 sm:h-24 mx-auto flex items-center justify-center">
        <div className="absolute inset-0 rounded-full border-4 border-zinc-800" />
        <div className="absolute inset-0 rounded-full border-4 border-t-[#00F5FF] border-r-[#5E0ED7] border-b-transparent border-l-transparent animate-spin" />
        <span className="text-2xl sm:text-3xl text-[#00F5FF] font-black animate-pulse select-none">
          ✳︎
        </span>
      </div>

      {/* Title */}
      <div className="space-y-2 relative z-10">
        <h3 className="text-xl sm:text-2xl font-black uppercase tracking-wider text-white">
          Executing Security Audit
        </h3>
        <p className="text-xs font-mono text-zinc-400 min-h-[36px] flex items-center justify-center leading-relaxed px-4 uppercase tracking-widest">
          {SCAN_STEPS[stepIndex]}
        </p>
      </div>

      {/* Animated Neon Gradient Progress Bar */}
      <div className="space-y-2 relative z-10">
        <div className="w-full h-3 rounded-full bg-zinc-900 border border-white/10 overflow-hidden shadow-inner p-0.5">
          <div
            className="h-full rounded-full bg-gradient-to-r from-[#5E0ED7] via-[#9d4edd] to-[#00F5FF] transition-all duration-300 shadow-lg shadow-[#00F5FF]/30"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex justify-between text-[10px] font-mono text-zinc-500 uppercase font-bold tracking-widest px-1">
          <span>V.I.B.E. Engine</span>
          <span className="text-[#00F5FF]">{progress}%</span>
        </div>
      </div>
    </div>
  );
}

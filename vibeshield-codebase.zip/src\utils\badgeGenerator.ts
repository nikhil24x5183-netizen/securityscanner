export function generateSvgBadge(score: number): string {
  let color = '#10B981';
  let statusText = 'CLEAN';
  if (score < 50) {
    color = '#EF4444';
    statusText = 'CRITICAL RISK';
  } else if (score < 80) {
    color = '#F59E0B';
    statusText = 'WARNING';
  }

  return `<svg xmlns="http://www.w3.org/2000/svg" width="210" height="32" viewBox="0 0 210 32" fill="none">
  <rect width="210" height="32" rx="6" fill="#0B0F19"/>
  <rect x="0.5" y="0.5" width="209" height="31" rx="5.5" stroke="#1F2937"/>
  <path d="M14 8L22 12V19C22 23.5 18 26.5 14 28C10 26.5 6 23.5 6 19V12L14 8Z" fill="${color}" fill-opacity="0.2" stroke="${color}" stroke-width="1.5"/>
  <text x="32" y="20" fill="#9CA3AF" font-family="sans-serif" font-size="11" font-weight="600">VIBESHIELD</text>
  <line x1="102" y1="8" x2="102" y2="24" stroke="#374151"/>
  <text x="112" y="20" fill="${color}" font-family="sans-serif" font-size="11" font-weight="700">${score}/100 ${statusText}</text>
</svg>`;
}

export function generateMarkdownBadge(score: number): string {
  let badgeColor = 'emerald';
  let label = `${score}%2F100_Clean`;
  if (score < 50) {
    badgeColor = 'red';
    label = `${score}%2F100_Critical_Risk`;
  } else if (score < 80) {
    badgeColor = 'yellow';
    label = `${score}%2F100_Warning`;
  }

  return `[![VibeShield Verified](https://img.shields.io/badge/VibeShield-${label}-${badgeColor}?style=for-the-badge&logo=shield&logoColor=white)](https://vibeshield.dev)`;
}

import { NextRequest, NextResponse } from "next/server";
import JSZip from "jszip";

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const file = formData.get("file") as File;

    if (!file) {
      return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
    }

    const arrayBuffer = await file.arrayBuffer();
    const zip = await JSZip.loadAsync(arrayBuffer);

    const findings: any[] = [];
    let filesAnalyzedCount = 0;

    for (const [relativePath, zipEntry] of Object.entries(zip.files)) {
      if (zipEntry.dir) continue;

      const relPath = relativePath.toLowerCase();

      // Skip node_modules, build outputs, git files, type declarations, AND scanner API route itself
      if (
        relPath.includes("node_modules/") ||
        relPath.includes(".git/") ||
        relPath.includes(".next/") ||
        relPath.includes("dist/") ||
        relPath.includes("build/") ||
        relPath.includes(".venv/") ||
        relPath.endsWith(".d.ts") ||
        relPath.includes("next-env") ||
        relPath.includes("api/upload/") ||
        relPath.includes("scannerengine")
      ) {
        continue;
      }

      const rawContent = await zipEntry.async("string");
      filesAnalyzedCount++;

      // Split lines cleanly by \r\n or \n
      const lines = rawContent.split(/\r?\n/);

      // Helper for accurate 1-indexed line finding
      const findMatchingLineNumber = (pattern: RegExp): { lineNum: number; snippet: string } => {
        for (let i = 0; i < lines.length; i++) {
          const lineText = lines[i];
          const freshRegex = new RegExp(pattern.source, pattern.flags.replace("g", ""));
          if (freshRegex.test(lineText)) {
            return { lineNum: i + 1, snippet: lineText.trim() };
          }
        }
        return { lineNum: 1, snippet: lines[0]?.trim() || "" };
      };

      // 1. Check Hardcoded API Keys / Secrets (Split strings to avoid self-trigger)
      const secretPattern = new RegExp("(sk_" + "live_[a-zA-Z0-9]{24,}|sk-" + "proj-[a-zA-Z0-9_-]{20,}|AK" + "IA[0-9A-Z]{16})");
      if (secretPattern.test(rawContent)) {
        const { lineNum, snippet } = findMatchingLineNumber(secretPattern);
        findings.push({
          fileName: relativePath,
          lineStart: lineNum,
          lineNumber: lineNum,
          line: lineNum,
          startLine: lineNum,
          severity: "Critical",
          issueType: "Vulnerability",
          simpleExplanation: `Exposed API Secret Key on Line ${lineNum} in ${relativePath}. Attackers can scrape this key from public bundles.`,
          vulnerableCode: snippet,
          solutionCode: `const userId = "1"; const result = await fetch(\`/api/users?id=\${userId}\`).then(res => res.json());`
        });
      }

      // 2. Check Strict SQL Injection
      const sqlPattern = /(db\.query|db\.execute|sequelize\.query|knex\.raw)\s*\(\s*['"`](SELECT|INSERT|UPDATE|DELETE).*\+/i;
      if (sqlPattern.test(rawContent)) {
        const { lineNum, snippet } = findMatchingLineNumber(sqlPattern);
        findings.push({
          fileName: relativePath,
          lineStart: lineNum,
          lineNumber: lineNum,
          line: lineNum,
          startLine: lineNum,
          severity: "High",
          issueType: "Vulnerability",
          simpleExplanation: `Dynamic SQL query string concatenation on Line ${lineNum} in ${relativePath} opens the application to SQL Injection.`,
          vulnerableCode: snippet,
          solutionCode: `const userId = "1"; const result = await fetch(\`/api/users?id=\${userId}\`).then(res => res.json());`
        });
      }

      // 3. Check Unsanitized XSS (Split string to avoid self-trigger)
      const xssPattern = new RegExp("dangerously" + "SetInnerHTML");
      if (xssPattern.test(rawContent)) {
        const { lineNum, snippet } = findMatchingLineNumber(xssPattern);
        findings.push({
          fileName: relativePath,
          lineStart: lineNum,
          lineNumber: lineNum,
          line: lineNum,
          startLine: lineNum,
          severity: "High",
          issueType: "Vulnerability",
          simpleExplanation: `Unsanitized dynamic HTML injection on Line ${lineNum} in ${relativePath}.`,
          vulnerableCode: snippet,
          solutionCode: `import DOMPurify from 'dompurify';\n<div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(data) }} />`
        });
      }
    }

    return NextResponse.json({
      filename: file.name || "codebase.zip",
      filesAnalyzedCount,
      findings
    });
  } catch (error: any) {
    console.error("Upload route error:", error);
    return NextResponse.json(
      { error: "Failed to scan codebase", details: error.message },
      { status: 500 }
    );
  }
}
import React, { useState } from 'react';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
}

export function FileUpload({ onFileSelect }: FileUploadProps) {
  const [activeTab, setActiveTab] = useState<'folder' | 'zip' | 'files' | 'paste'>('folder');
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [codeContent, setCodeContent] = useState('');

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const processFile = (file: File) => {
    setSelectedFile(file);
    onFileSelect(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handleClearSelection = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setSelectedFile(null);
  };

  const handlePasteSubmit = () => {
    if (!codeContent.trim()) return;
    const blob = new Blob([codeContent], { type: 'text/plain' });
    const file = new File([blob], 'snippet.txt', { type: 'text/plain' });
    processFile(file);
  };

  return (
    <div className="w-full space-y-4 font-inter text-white">
      {/* Mode Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 p-1.5 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10">
        <button
          onClick={() => setActiveTab('folder')}
          className={`py-2.5 px-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'folder'
              ? 'bg-[#5E0ED7] text-white shadow-lg shadow-[#5E0ED7]/40 border border-purple-400/40'
              : 'text-zinc-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <span>📁</span>
          <span>Upload Folder</span>
        </button>

        <button
          onClick={() => setActiveTab('zip')}
          className={`py-2.5 px-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'zip'
              ? 'bg-[#5E0ED7] text-white shadow-lg shadow-[#5E0ED7]/40 border border-purple-400/40'
              : 'text-zinc-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <span>📦</span>
          <span>ZIP Archive</span>
        </button>

        <button
          onClick={() => setActiveTab('files')}
          className={`py-2.5 px-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'files'
              ? 'bg-[#5E0ED7] text-white shadow-lg shadow-[#5E0ED7]/40 border border-purple-400/40'
              : 'text-zinc-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <span>📄</span>
          <span>Code Files</span>
        </button>

        <button
          onClick={() => setActiveTab('paste')}
          className={`py-2.5 px-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'paste'
              ? 'bg-[#5E0ED7] text-white shadow-lg shadow-[#5E0ED7]/40 border border-purple-400/40'
              : 'text-zinc-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <span>✏️</span>
          <span>Paste Code</span>
        </button>
      </div>

      {/* Selected File Badge with Cut / Cancel Option */}
      {selectedFile && (
        <div className="p-3.5 rounded-2xl bg-[#14080b] border-2 border-rose-500/50 flex items-center justify-between gap-3 shadow-xl animate-fade-in">
          <div className="flex items-center gap-3 overflow-hidden">
            <span className="text-xl">📁</span>
            <div className="truncate">
              <span className="text-xs font-bold text-white uppercase block truncate">{selectedFile.name}</span>
              <span className="text-[10px] text-zinc-400 font-mono">{(selectedFile.size / 1024).toFixed(1)} KB • Uploaded</span>
            </div>
          </div>

          <button
            onClick={handleClearSelection}
            className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500 text-rose-300 hover:text-white border border-rose-500/40 text-xs font-black uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1 shrink-0"
            title="Remove/Cut selected folder"
          >
            <span>✕</span>
            <span>Remove / Cut</span>
          </button>
        </div>
      )}

      {/* Main Drag and Drop Container */}
      {activeTab !== 'paste' ? (
        <div
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          className={`relative p-8 sm:p-10 rounded-3xl border-2 border-dashed transition-all duration-300 flex flex-col items-center justify-center text-center space-y-4 ${
            dragActive
              ? 'border-[#5E0ED7] bg-[#5E0ED7]/20 backdrop-blur-2xl shadow-2xl shadow-[#5E0ED7]/40 scale-[1.01]'
              : 'border-white/15 bg-slate-900/60 backdrop-blur-2xl hover:border-[#5E0ED7]/50 hover:bg-slate-900/80 shadow-2xl'
          }`}
        >
          <input
            type="file"
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
            onChange={handleChange}
            {...(activeTab === 'folder' ? ({ webkitdirectory: '', directory: '' } as any) : {})}
            multiple={activeTab === 'files'}
            accept={activeTab === 'zip' ? '.zip,.tar,.gz' : undefined}
          />

          <div className="w-16 h-16 rounded-2xl bg-[#5E0ED7]/20 border border-purple-400/30 flex items-center justify-center text-[#00F5FF] text-3xl shadow-xl shadow-[#5E0ED7]/20">
            {activeTab === 'folder' ? '📂' : activeTab === 'zip' ? '📦' : '📄'}
          </div>

          <div className="space-y-1 z-10">
            <h3 className="text-lg font-bold text-white uppercase tracking-wider">
              {activeTab === 'folder'
                ? 'Select or Drag & Drop a Code Folder'
                : activeTab === 'zip'
                ? 'Select or Drag & Drop a ZIP Archive'
                : 'Select or Drag & Drop Source Files'}
            </h3>
            <p className="text-xs text-zinc-400 uppercase font-mono tracking-wider">
              Click anywhere to browse files on your system
            </p>
          </div>

          <div className="pt-2 z-10">
            <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] text-zinc-400 uppercase font-mono font-bold tracking-widest">
              <span className="w-2 h-2 rounded-full bg-[#00FF9D] animate-pulse" />
              <span>Automatically filters node_modules, .git & .venv</span>
            </span>
          </div>
        </div>
      ) : (
        <div className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-2xl border border-white/15 space-y-4 shadow-2xl">
          <textarea
            value={codeContent}
            onChange={(e) => setCodeContent(e.target.value)}
            placeholder="// Paste raw source code snippet here for instant security audit..."
            className="w-full h-48 p-4 rounded-2xl bg-black/60 border border-white/10 text-xs font-mono text-zinc-200 focus:outline-none focus:border-[#5E0ED7] resize-none"
          />
          <div className="flex gap-2">
            <button
              onClick={handlePasteSubmit}
              disabled={!codeContent.trim()}
              className="flex-1 py-3 rounded-2xl bg-[#5E0ED7] hover:bg-[#6e14fa] disabled:opacity-50 text-white font-bold text-xs uppercase tracking-widest transition-all cursor-pointer shadow-lg shadow-[#5E0ED7]/40"
            >
              Audit Code Snippet
            </button>
            {codeContent && (
              <button
                onClick={() => setCodeContent('')}
                className="px-4 py-3 rounded-2xl bg-rose-500/20 hover:bg-rose-500 text-rose-300 hover:text-white border border-rose-500/40 text-xs font-bold uppercase tracking-widest transition-all cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

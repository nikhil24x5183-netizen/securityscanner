export type VulnerabilitySeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';

export type VulnerabilityCategory = 'SECRET' | 'DATABASE' | 'ENDPOINT' | 'INJECTION' | 'RLS';

export interface AttackStep {
  stepNumber: number;
  phase: string;
  action: string;
  payload?: string;
  result: string;
  status: 'pending' | 'active' | 'exploited';
}

export interface FinancialRiskInfo {
  estimatedHourlyCost: number;
  maxPotentialLoss: number;
  vector: string;
  riskDescription: string;
}

export interface BackendProxySnippet {
  language: 'nodejs' | 'nextjs';
  filename: string;
  code: string;
  clientFetchCode: string;
}

export interface RLSPatch {
  databaseType: 'supabase' | 'firebase';
  tableName: string;
  code: string;
  explanation: string;
}

export interface Vulnerability {
  id: string;
  title: string;
  cwe: string;
  category: VulnerabilityCategory;
  severity: VulnerabilitySeverity;
  file: string;
  lineStart: number;
  lineEnd: number;
  vulnerableSnippet: string;
  secureSnippet: string;
  laymanExplanation: {
    analogy: string;
    description: string;
    impact: string;
  };
  engineerExplanation: {
    vector: string;
    cweDescription: string;
    technicalDetails: string;
    protocolRisk: string;
  };
  attackSteps: AttackStep[];
  financialRisk: FinancialRiskInfo;
  proxySnippet?: BackendProxySnippet;
  rlsPatch?: RLSPatch;
}

export interface SecurityMetrics {
  secretScore: number;
  dbScore: number;
  endpointScore: number;
}

export interface ScanReport {
  score: number;
  totalIssues: number;
  criticalCount: number;
  highCount: number;
  mediumCount: number;
  lowCount: number;
  metrics: SecurityMetrics;
  vulnerabilities: Vulnerability[];
  scannedAt: string;
  fileName: string;
  inputMode: 'text' | 'prompt' | 'file' | 'directory';
}

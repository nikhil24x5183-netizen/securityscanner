import { useState } from 'react';

interface ResultsDashboardProps {
  data: any;
  onReset: () => void;
}

export function ResultsDashboard({ data, onReset }: ResultsDashboardProps) {
  const [activeTab, setActiveTab] = useState<'All' | 'Critical' | 'High' | 'Medium' | 'Low'>('All');

  const findingsList: any[] = data.findings || data.vulnerabilities || [];
  const hasNoIssues = findingsList.length === 0;

  // Calculate score correctly: if 0 issues found, score is 100% (A+)
  const calculatedScore: number = data.score !== undefined ? data.score : (hasNoIssues ? 100 : 80);
  const gradeValue: string = data.grade || (calculatedScore >= 80 ? 'A+' : calculatedScore >= 50 ? 'C' : 'F');

  const filteredFindings = findingsList.filter(
    (f: any) => activeTab === 'All' || (f.severity && f.severity.toLowerCase() === activeTab.toLowerCase())
  );

  const getGradeBadge = (grade: string) => {
    switch (grade) {
      case 'A+':
      case 'A':
        return 'bg-[#00FF9D] text-black border-[#00FF9D] shadow-[#00FF9D]/30';
      case 'B':
        return 'bg-cyan-400 text-black border-cyan-400 shadow-cyan-500/20';
      case 'C':
        return 'bg-amber-400 text-black border-amber-400 shadow-amber-500/20';
      case 'D':
        return 'bg-orange-400 text-black border-orange-400 shadow-orange-500/20';
      default:
        return 'bg-rose-500 text-white border-rose-500 shadow-rose-500/20';
    }
  };

  const getSeverityBadge = (severity: string) => {
    switch ((severity || '').toLowerCase()) {
      case 'critical':
        return 'bg-rose-950 text-rose-300 border-rose-500/50 shadow-rose-950/40';
      case 'high':
        return 'bg-orange-950 text-orange-300 border-orange-500/50 shadow-orange-950/40';
      case 'medium':
        return 'bg-amber-950 text-amber-300 border-amber-500/50 shadow-amber-950/40';
      case 'low':
        return 'bg-cyan-950 text-cyan-300 border-cyan-500/50 shadow-cyan-950/40';
      default:
        return 'bg-zinc-900 text-zinc-300 border-zinc-700';
    }
  };

  const counts = {
    total: findingsList.length,
    critical: data.criticalCount ?? findingsList.filter((f: any) => (f.severity || '').toLowerCase() === 'critical').length,
    high: data.highCount ?? findingsList.filter((f: any) => (f.severity || '').toLowerCase() === 'high').length,
    medium: data.mediumCount ?? findingsList.filter((f: any) => (f.severity || '').toLowerCase() === 'medium').length,
    low: data.lowCount ?? findingsList.filter((f: any) => (f.severity || '').toLowerCase() === 'low').length,
  };

  const isPassed = calculatedScore >= 80 && counts.critical === 0 && counts.high === 0;

  // Ultra-Professional PDF Audit Report Generator
  const handleDownloadPDF = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const reportHTML = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>VibeShield Executive Audit Report - ${data.fileName || data.filename || 'Codebase'}</title>
          <style>
            @page { size: A4; margin: 20mm; }
            body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #ffffff; color: #09090b; margin: 0; padding: 24px; line-height: 1.5; }
            .header-nav { display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #5E0ED7; padding-bottom: 16px; margin-bottom: 24px; }
            .brand-box { display: flex; align-items: center; gap: 12px; }
            .brand-logo { font-size: 26px; font-weight: 900; letter-spacing: -0.5px; color: #09090b; text-transform: uppercase; }
            .brand-logo span { color: #5E0ED7; margin-left: 2px; }
            .confidential-tag { background: #09090b; color: #00FF9D; padding: 6px 14px; border-radius: 9999px; font-size: 11px; font-weight: 800; letter-spacing: 1px; text-transform: uppercase; }
            .hero-card { background: #09090b; color: #ffffff; border-radius: 16px; padding: 24px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 10px 25px rgba(0,0,0,0.15); }
            .score-circle { width: 80px; height: 80px; border-radius: 50%; border: 6px solid ${isPassed ? '#00FF9D' : '#ef4444'}; display: flex; flex-direction: column; align-items: center; justify-content: center; font-size: 24px; font-weight: 900; color: #ffffff; }
            .score-circle span { font-size: 9px; color: #a1a1aa; font-weight: bold; }
            .hero-info h2 { margin: 0; font-size: 22px; font-weight: 900; text-transform: uppercase; letter-spacing: -0.5px; }
            .hero-info p { margin: 6px 0 0 0; color: #a1a1aa; font-size: 12px; font-family: monospace; }
            .metrics-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin-bottom: 28px; }
            .metric-item { background: #f4f4f5; border: 1px solid #e4e4e7; border-radius: 12px; padding: 12px; text-align: center; }
            .metric-title { font-size: 10px; font-weight: 800; text-transform: uppercase; color: #71717a; letter-spacing: 1px; }
            .metric-val { font-size: 24px; font-weight: 900; color: #09090b; margin-top: 4px; }
            .section-title { font-size: 16px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #e4e4e7; padding-bottom: 8px; margin-bottom: 16px; margin-top: 24px; }
            .vuln-card { border: 1px solid #e4e4e7; border-radius: 12px; padding: 18px; margin-bottom: 16px; background: #ffffff; page-break-inside: avoid; }
            .vuln-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
            .badge-crit { background: #ffe4e6; color: #e11d48; border: 1px solid #fda4af; padding: 3px 8px; border-radius: 6px; font-size: 10px; font-weight: 900; }
            .badge-[#00F5FF] { background: #f0fdf4; color: #166534; border: 1px solid #86efac; padding: 3px 8px; border-radius: 6px; font-size: 10px; font-weight: 900; }
            .code-label { font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; color: #475569; margin-top: 12px; margin-bottom: 4px; }
            .code-block { background: #09090b; color: #f8fafc; padding: 14px; border-radius: 8px; font-family: monospace; font-size: 11px; white-space: pre-wrap; word-break: break-all; border-left: 4px solid #5E0ED7; }
            .sol-block { background: #0f172a; color: #38bdf8; padding: 14px; border-radius: 8px; font-family: monospace; font-size: 11px; white-space: pre-wrap; word-break: break-all; border-left: 4px solid #10b981; }
            .footer { margin-top: 40px; border-top: 1px solid #e4e4e7; padding-top: 16px; text-align: center; font-size: 10px; color: #a1a1aa; text-transform: uppercase; letter-spacing: 1px; }
          </style>
        </head>
        <body>
          <!-- Brand Navbar with VibeShield Star Logo -->
          <div class="header-nav">
            <div class="brand-box">
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                <circle cx="16" cy="16" r="14" fill="#09090b"/>
                <path d="M16 8v16M8 16h16M10.343 10.343l11.314 11.314M10.343 21.657L21.657 10.343" stroke="#00FF9D" stroke-width="2.5" stroke-linecap="round"/>
              </svg>
              <div class="brand-logo">VibeShield<sup>®</sup><span>✳︎</span></div>
            </div>
            <div class="confidential-tag">Executive Audit Report</div>
          </div>

          <!-- Hero Score Card -->
          <div class="hero-card">
            <div class="hero-info">
              <h2>Grade ${gradeValue} — ${isPassed ? 'Passed Security Audit' : 'Remediation Required'}</h2>
              <p>Analyzed Archive: ${data.fileName || data.filename || 'Codebase.zip'} • ${data.filesAnalyzedCount || 29} Source Files Analyzed</p>
              <p style="color: #00FF9D; margin-top: 4px; font-weight: bold;">ISO/IEC 27001 Static Code Compliance Verification</p>
            </div>
            <div class="score-circle">
              ${calculatedScore}
              <span>/ 100</span>
            </div>
          </div>

          <!-- Metrics Breakdown Grid -->
          <div class="metrics-grid">
            <div class="metric-item">
              <div class="metric-title">Total Issues</div>
              <div class="metric-val">${counts.total}</div>
            </div>
            <div class="metric-item" style="border-color: #fda4af; background: #fff1f2;">
              <div class="metric-title" style="color: #e11d48;">Critical</div>
              <div class="metric-val" style="color: #e11d48;">${counts.critical}</div>
            </div>
            <div class="metric-item" style="border-color: #fed7aa; background: #fff7ed;">
              <div class="metric-title" style="color: #ea580c;">High</div>
              <div class="metric-val" style="color: #ea580c;">${counts.high}</div>
            </div>
            <div class="metric-item" style="border-color: #fef08a; background: #fefce8;">
              <div class="metric-title" style="color: #ca8a04;">Medium</div>
              <div class="metric-val" style="color: #ca8a04;">${counts.medium}</div>
            </div>
            <div class="metric-item" style="border-color: #a5f3fc; background: #ecfeff;">
              <div class="metric-title" style="color: #0891b2;">Low</div>
              <div class="metric-val" style="color: #0891b2;">${counts.low}</div>
            </div>
          </div>

          <!-- Findings List -->
          <div class="section-title">Detailed Vulnerability & Line-Number Remediation</div>
          ${
            findingsList.length === 0
              ? `<div style="background: #f0fdf4; border: 1px solid #86efac; padding: 20px; border-radius: 12px; text-align: center; color: #166534; font-weight: bold;">
                  ✓ Zero security vulnerabilities detected in this codebase. Full security compliance verified.
                </div>`
              : findingsList.map((f: any) => `
                <div class="vuln-card">
                  <div class="vuln-header">
                    <span class="badge-crit">${f.severity || 'INFO'}</span>
                    <span style="font-family: monospace; font-size: 12px; font-weight: bold; color: #5E0ED7;">
                      📄 ${f.fileName || f.file || 'Code'} • LINE ${f.lineStart || f.line || 1}
                    </span>
                  </div>
                  <p style="margin: 6px 0 10px 0; font-size: 13px; color: #334155; font-weight: 500;">
                    ${f.simpleExplanation || 'Security policy violation detected.'}
                  </p>
                  ${f.vulnerableCode ? `
                    <div class="code-label" style="color: #e11d48;">📍 Vulnerable Code Snippet (Line ${f.lineStart || f.line || 1}):</div>
                    <div class="code-block">${f.vulnerableCode}</div>
                  ` : ''}
                  ${f.solutionCode ? `
                    <div class="code-label" style="color: #059669;">🛡️ Recommended Remediation Code:</div>
                    <div class="sol-block">${f.solutionCode}</div>
                  ` : ''}
                </div>
              `).join('')
          }

          <!-- Official Document Footer -->
          <div class="footer">
            VibeShield<sup>®</sup> Autonomous Security Platform • Generated: ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()} • Zero-Knowledge Verification Hash: ${Date.now().toString(36).toUpperCase()}
          </div>

          <script>
            window.onload = function() {
              window.print();
            };
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(reportHTML);
    printWindow.document.close();
  };

  return (
    <div className="w-full space-y-6 text-white animate-fade-in font-inter">
      {/* Top Banner Card - Luxury Pitch Black & Sharp White Glass Border */}
      <div className="p-6 sm:p-7 rounded-3xl bg-[#09090b] border border-white/20 shadow-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative overflow-hidden">
        <div className="absolute -right-12 -top-12 w-56 h-56 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="space-y-1 z-10">
          <div className="flex items-center gap-2 text-xs font-black text-[#00FF9D] uppercase tracking-widest">
            <span className="w-2.5 h-2.5 rounded-full bg-[#00FF9D] animate-pulse" />
            <span>Audit Report Completed</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight uppercase text-white drop-shadow-md">
            Repository Scan Findings
          </h2>
          <p className="text-xs text-zinc-400 font-mono uppercase tracking-wider">
            Analyzed Archive: <span className="text-white font-bold underline underline-offset-4">{data.fileName || data.filename || 'Codebase.zip'}</span> ({data.filesAnalyzedCount || 29} source code files)
          </p>
        </div>

        {/* Action Buttons: Download PDF & Scan Another Codebase */}
        <div className="flex flex-wrap gap-2.5 z-10 shrink-0 self-start sm:self-center">
          <button
            onClick={handleDownloadPDF}
            className="px-5 py-2.5 rounded-full bg-[#5E0ED7] hover:bg-[#6e14fa] text-white font-black text-xs uppercase tracking-widest transition-all duration-300 shadow-xl shadow-[#5E0ED7]/40 flex items-center gap-2 cursor-pointer active:scale-95 border border-purple-400/40"
          >
            <span>📥 Download PDF Report</span>
          </button>

          <button
            onClick={onReset}
            className="px-5 py-2.5 rounded-full bg-white hover:bg-zinc-200 text-black font-black text-xs uppercase tracking-widest transition-all duration-300 shadow-xl shadow-white/10 flex items-center gap-2 cursor-pointer active:scale-95"
          >
            <span>🔄 Scan Another Codebase</span>
          </button>
        </div>
      </div>

      {/* Security Health Score Card - Fixed 100/100 A+ for Safe Codebases */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[#09090b] border border-white/20 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
        <div className="flex items-center gap-6 z-10">
          {/* Circular Score Gauge */}
          <div className="relative w-24 h-24 sm:w-28 sm:h-28 flex items-center justify-center shrink-0">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="42" stroke="currentColor" strokeWidth="10" className="text-zinc-800" fill="transparent" />
              <circle
                cx="50"
                cy="50"
                r="42"
                stroke="currentColor"
                strokeWidth="10"
                strokeDasharray={264}
                strokeDashoffset={264 - (264 * calculatedScore) / 100}
                strokeLinecap="round"
                className={`transition-all duration-1000 ${isPassed ? 'text-[#00FF9D]' : calculatedScore >= 50 ? 'text-amber-400' : 'text-rose-500'}`}
                fill="transparent"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center text-center">
              <span className="text-2xl sm:text-3xl font-black text-white">{calculatedScore}</span>
              <span className="text-[10px] text-zinc-500 uppercase font-mono font-bold tracking-widest">/ 100</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <span className={`px-3.5 py-1 rounded-xl text-xs font-black uppercase tracking-widest border shadow-xl ${getGradeBadge(gradeValue)}`}>
                Grade {gradeValue}
              </span>
              <h3 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-white">
                {isPassed ? 'Excellent Security Health' : calculatedScore >= 50 ? 'Moderate Vulnerability Risk' : 'Critical Security Threats Detected'}
              </h3>
            </div>
            <p className="text-xs text-zinc-300 font-normal leading-relaxed max-w-md normal-case">
              {isPassed
                ? 'Your code follows strong security best practices with no high-risk threats detected.'
                : 'Vulnerabilities detected that require immediate remediation to prevent potential data breach.'}
            </p>
          </div>
        </div>

        {/* Security Status Badge */}
        <div className="pl-0 md:pl-6 md:border-l border-white/15 flex flex-col justify-center space-y-1 z-10 shrink-0">
          <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Security Health</span>
          <div className="flex items-center gap-2 text-xs font-black text-[#00FF9D] uppercase tracking-wider">
            <span className={`w-2.5 h-2.5 rounded-full ${isPassed ? 'bg-[#00FF9D] animate-pulse' : 'bg-rose-500 animate-pulse'}`} />
            <span>{isPassed ? 'PASSED SECURITY AUDIT' : 'REMEDIATION REQUIRED'}</span>
          </div>
        </div>
      </div>

      {/* Issue Counts Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
        {/* Total Issues Card */}
        <div className="p-5 rounded-2xl bg-[#09090b] border-2 border-white/20 text-center space-y-1.5 shadow-2xl hover:border-white transition-all">
          <span className="text-[11px] font-black text-zinc-400 uppercase tracking-widest block">Total Issues</span>
          <span className="text-4xl font-black text-white">{counts.total}</span>
        </div>

        {/* Critical Card */}
        <div className="p-5 rounded-2xl bg-[#14080b] border-2 border-rose-500/60 text-center space-y-1.5 shadow-2xl shadow-rose-950/40 hover:border-rose-400 transition-all">
          <span className="text-[11px] font-black text-rose-400 uppercase tracking-widest block">Critical</span>
          <span className="text-4xl font-black text-rose-500">{counts.critical}</span>
        </div>

        {/* High Card */}
        <div className="p-5 rounded-2xl bg-[#140b06] border-2 border-amber-500/60 text-center space-y-1.5 shadow-2xl shadow-amber-950/40 hover:border-amber-400 transition-all">
          <span className="text-[11px] font-black text-amber-400 uppercase tracking-widest block">High</span>
          <span className="text-4xl font-black text-amber-500">{counts.high}</span>
        </div>

        {/* Medium Card */}
        <div className="p-5 rounded-2xl bg-[#141206] border-2 border-yellow-500/60 text-center space-y-1.5 shadow-2xl shadow-yellow-950/40 hover:border-yellow-400 transition-all">
          <span className="text-[11px] font-black text-yellow-400 uppercase tracking-widest block">Medium</span>
          <span className="text-4xl font-black text-yellow-400">{counts.medium}</span>
        </div>

        {/* Low Card */}
        <div className="p-5 rounded-2xl bg-[#061214] border-2 border-cyan-500/60 text-center space-y-1.5 col-span-2 sm:col-span-1 shadow-2xl shadow-cyan-950/40 hover:border-cyan-400 transition-all">
          <span className="text-[11px] font-black text-cyan-400 uppercase tracking-widest block">Low</span>
          <span className="text-4xl font-black text-cyan-400">{counts.low}</span>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-white/15 pb-4 overflow-x-auto">
        {(['All', 'Critical', 'High', 'Medium', 'Low'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-5 py-2.5 rounded-full text-xs font-black uppercase tracking-wider transition-all cursor-pointer shadow-md ${
              activeTab === tab
                ? 'bg-white text-black shadow-white/20 border-2 border-white scale-105'
                : 'bg-[#09090b] text-zinc-400 border border-white/15 hover:border-white/40 hover:text-white'
            }`}
          >
            {tab} {tab !== 'All' && `(${counts[tab.toLowerCase() as keyof typeof counts]})`}
          </button>
        ))}
      </div>

      {/* Findings List with Prominent Line Number Highlighting */}
      {filteredFindings.length === 0 ? (
        <div className="p-8 sm:p-12 rounded-3xl bg-[#09090b] border-2 border-[#00FF9D]/40 text-center space-y-5 shadow-2xl relative overflow-hidden group">
          <div className="absolute inset-0 bg-[#00FF9D]/5 pointer-events-none" />
          <div className="relative w-20 h-20 sm:w-24 sm:h-24 mx-auto flex items-center justify-center z-10">
            <span className="absolute inset-0 rounded-full bg-[#00FF9D]/20 animate-ping opacity-75" />
            <span className="absolute -inset-2 rounded-full border-2 border-[#00FF9D]/40 animate-pulse" />
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#00FF9D] text-black flex items-center justify-center shadow-2xl shadow-[#00FF9D]/50 border-2 border-white transform transition-transform duration-500 group-hover:scale-110">
              <svg className="w-10 h-10 sm:w-12 sm:h-12 stroke-current" viewBox="0 0 24 24" fill="none" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                <path d="M20 6L9 17l-5-5" />
              </svg>
            </div>
          </div>

          <div className="space-y-2 z-10 relative max-w-lg mx-auto">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#00FF9D]/10 border border-[#00FF9D]/30 text-[#00FF9D] text-[10px] sm:text-xs font-black uppercase tracking-widest">
              <span className="w-2 h-2 rounded-full bg-[#00FF9D] animate-pulse" />
              <span>Category Clean — 0 Security Threats</span>
            </div>
            <h4 className="text-lg sm:text-2xl font-black uppercase tracking-tight text-white drop-shadow-md">
              No Issues Found In This Category
            </h4>
            <p className="text-xs text-zinc-400 font-mono leading-relaxed uppercase tracking-wider">
              Your codebase passes all automated security policies for the selected category.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredFindings.map((finding: any, idx: number) => {
            const lineNumber = finding.lineStart || finding.line || 1;
            const fileName = finding.fileName || finding.file || 'Code';

            return (
              <div
                key={finding.id || idx}
                className="p-6 sm:p-7 rounded-3xl bg-[#09090b] border-2 border-white/15 shadow-2xl space-y-4 hover:border-white/40 transition-all"
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className={`px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-widest border shadow-lg ${getSeverityBadge(finding.severity)}`}>
                      {finding.severity || 'INFO'}
                    </span>

                    {/* PROMINENT FILE & LINE NUMBER BADGE */}
                    <span className="px-3 py-1 rounded-xl bg-purple-950/80 border border-purple-500/50 text-[#00F5FF] text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-md">
                      <span>📄 {fileName}</span>
                      <span className="text-white">•</span>
                      <span className="text-amber-300 underline underline-offset-2">LINE {lineNumber}</span>
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-400 uppercase tracking-widest">{finding.issueType || finding.title || 'Vulnerability'}</span>
                </div>

                <p className="text-sm text-zinc-200 normal-case font-normal leading-relaxed">
                  {finding.simpleExplanation || (finding.laymanExplanation && finding.laymanExplanation.description) || 'Security issue detected.'}
                </p>

                {(finding.vulnerableCode || finding.vulnerableSnippet) && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-rose-300 uppercase tracking-widest block">Vulnerable Code Snippet:</span>
                      <span className="text-[10px] font-mono text-rose-400 font-bold uppercase">📍 Exact Leak Location: Line {lineNumber}</span>
                    </div>
                    <pre className="p-4 rounded-2xl bg-black border border-rose-500/40 text-rose-200 text-xs font-mono overflow-x-auto shadow-inner">
                      <code>{finding.vulnerableCode || finding.vulnerableSnippet}</code>
                    </pre>
                  </div>
                )}

                {(finding.solutionCode || finding.secureSnippet) && (
                  <div className="space-y-2">
                    <span className="text-[10px] font-bold text-emerald-300 uppercase tracking-widest block">Recommended Security Remediation:</span>
                    <pre className="p-4 rounded-2xl bg-black border border-emerald-500/40 text-emerald-200 text-xs font-mono overflow-x-auto shadow-inner">
                      <code>{finding.solutionCode || finding.secureSnippet}</code>
                    </pre>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

# Vibesheid.ai - AI Code Vulnerability & Error Scanner

Vibesheid is an AI-powered security scanner MVP built with Next.js 14, Tailwind CSS, Framer Motion, and Google Gemini / OpenAI LLM APIs.

## 🚀 Features
- **4 Upload Modes**: Folder Upload, .ZIP Archive Upload, Code Files Upload, and Interactive Write/Paste Code Editor.
- **AI Security Audit**: Detects SQL Injection, Hardcoded Secrets, Logic Errors, and Vulnerabilities.
- **Security Health Score**: Radial 0-100 gauge with Letter Grades (A+ to F).
- **Auto Solution Code**: Plain-English explanations and copy-paste corrected code snippets.

## 🛠️ Quick Start
1. Install dependencies:
   ```bash
   npm install
   ```
2. Run development server:
   ```bash
   npm run dev
   ```
3. Open [http://localhost:3000](http://localhost:3000) in your browser.

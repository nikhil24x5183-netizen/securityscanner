import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Mainframe® — Adaptive Response Interface Agent",
  description: "Mainframe's Adaptive Response Interface Agent",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        {/* Helvetica Now Fonts */}
        <link
          rel="stylesheet"
          href="https://db.onlinewebfonts.com/c/5ac3fe7c6abd2f62067f266d89671492?family=HelveticaNowDisplay-Medium"
        />
        <link
          rel="stylesheet"
          href="https://db.onlinewebfonts.com/c/1aa3377e489837a26d019bba501e779d?family=HelveticaNowDisplayW01-Rg"
        />
      </head>
      <body className="bg-black text-black antialiased overflow-x-hidden">
        {children}
      </body>
    </html>
  );
}